extends PanelContainer


func _on_button_pressed() -> void:
	GameInputEvents.use_tool()
