extends Button


func _on_button_down() -> void:
	var action = InputEventAction.new()
	action.action = "useTool"
	action.pressed = true
	Input.parse_input_event(action)


func _on_button_up() -> void:
	var action = InputEventAction.new()
	action.action = "useTool"
	action.pressed = false
	Input.parse_input_event(action)
